#pragma once

using namespace System::IO;

#include "stdafx.h"

__gc class CConfigWriter
{
private:
	CConfig *Config;
	RichTextBox *txtConsole;

public:
	CConfigWriter(CConfig *Config, RichTextBox *txtConsole);
	bool WriteConfigFile(String *sFile);
};