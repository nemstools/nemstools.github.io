#pragma once

using namespace System::IO;

#include "stdafx.h"

__gc class CConfigLoader
{
private:
	CConfig *Config;
	RichTextBox *txtConsole;

public:
	CConfigLoader(CConfig *Config, RichTextBox *txtConsole);
	bool LoadConfigFile(String *sFile);

private:
	bool ProcessLine(String *sLine, String **sArg, String **sVal);
};