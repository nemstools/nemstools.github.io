using System;
using PaintDotNet;

namespace VtfFileTypePlugin
{
	internal class VtfSaveConfigWidget : PaintDotNet.SaveConfigWidget
    {
        private bool bUpdatingFlags;
        private bool bUpdatingToken;
        private System.Windows.Forms.Label lblMipmapFilter;
        private System.Windows.Forms.CheckBox chkGenerateMipmaps;
        private System.Windows.Forms.ComboBox cboMipmapFilter;
        private System.Windows.Forms.ComboBox cboMipmapSharpenFilter;
        private System.Windows.Forms.Label lblMipmapSharpenFilter;
        private System.Windows.Forms.GroupBox grpImageFlags;
        private System.Windows.Forms.CheckedListBox lstImageFlags;
        private System.Windows.Forms.GroupBox grpNormalmaps;
        private System.Windows.Forms.ComboBox cboNormalmapKernelFilter;
        private System.Windows.Forms.Label lblNormalmapKernelFilter;
        private System.Windows.Forms.CheckBox chkGenerateNormalmap;
        private System.Windows.Forms.ComboBox cboNormalmapHeightConversionMethod;
        private System.Windows.Forms.Label lblNormalmapHeightConversionMethod;
        private System.Windows.Forms.ComboBox cboNormalmapAlphaResult;
        private System.Windows.Forms.Label lblNormalmapAlphaResult;
        private System.Windows.Forms.Label lblNormalmapScale;
        private System.Windows.Forms.NumericUpDown numNormalmapScale;
        private System.Windows.Forms.CheckBox chkNormalmapWrap;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabMipmaps;
        private System.Windows.Forms.TabPage tabFlags;
        private System.Windows.Forms.TabPage tabNormalmap;
        private System.Windows.Forms.TabPage tabGeneral;
        private System.Windows.Forms.GroupBox grpTemplate;
        private System.Windows.Forms.ComboBox cboTemplate;
        private System.Windows.Forms.GroupBox grpImageFormat;
        private System.Windows.Forms.ComboBox cboImageFormat;
        private System.Windows.Forms.GroupBox grpGeneral;
        private System.Windows.Forms.CheckBox chkGenerateThumbnail;
        private System.Windows.Forms.CheckBox chkAnimateLayers;
        private System.Windows.Forms.TabPage tabAdvanced;
        private System.Windows.Forms.GroupBox grpVersion;
        private System.Windows.Forms.ComboBox cboVersion;
		private System.Windows.Forms.GroupBox grpMipmaps;
	
		public VtfSaveConfigWidget()
        {
            this.bUpdatingFlags = false;
            this.bUpdatingToken = false;
			this.InitializeComponent();
        }

        protected override void InitFileType()
        {
            this.fileType = new VtfFileType();
        }

        protected override void InitTokenFromWidget()
        {
            VtfSaveConfigToken VtfToken = (VtfSaveConfigToken)this.token;

            VtfToken.eImageFormat = (VtfLib.ImageFormat)this.cboImageFormat.SelectedIndex;

            VtfToken.bAnimateLayers = this.chkAnimateLayers.Checked;
            VtfToken.bGenerateThumbnail = this.chkGenerateThumbnail.Checked;

            VtfToken.bGenerateMipmaps = this.chkGenerateMipmaps.Checked;
            VtfToken.eMipmapFilter = (VtfLib.MipmapFilter)this.cboMipmapFilter.SelectedIndex;
            VtfToken.eMipmapSharpenFilter = (VtfLib.SharpenFilter)this.cboMipmapSharpenFilter.SelectedIndex;

            VtfToken.uiImageFlags = 0;
            for (int i = 0; i < (int)VtfLib.ImageFlag.ImageFlagCount; i++)
            {
                if (this.lstImageFlags.GetItemChecked(i))
                {
                    VtfToken.uiImageFlags |= (uint)(1 << i);
                }
            }

            VtfToken.bGenerateNormalmap = this.chkGenerateNormalmap.Checked;
            VtfToken.eNormalmapKernelFilter = (VtfLib.KernelFilter)this.cboNormalmapKernelFilter.SelectedIndex;
            VtfToken.eNormalmapHeightConversionMethod = (VtfLib.HeightConversionMethod)this.cboNormalmapHeightConversionMethod.SelectedIndex;
            VtfToken.eNormalmapAlphaResult = (VtfLib.NormalAlphaResult)this.cboNormalmapAlphaResult.SelectedIndex;
            VtfToken.fNormalmapScale = this.numNormalmapScale.Value;
            VtfToken.bNormalmapWrap = this.chkNormalmapWrap.Checked;

            VtfToken.uiVersionMajor = Convert.ToUInt32(this.cboVersion.Text.Substring(0, 1));
            VtfToken.uiVersionMinor = Convert.ToUInt32(this.cboVersion.Text.Substring(2, 1));
        }

        protected override void InitWidgetFromToken(SaveConfigToken Token)
        {
            if (Token is VtfSaveConfigToken)
			{
                this.bUpdatingToken = true;

                VtfSaveConfigToken VtfToken = (VtfSaveConfigToken)Token;

                this.cboImageFormat.SelectedIndex = (int)VtfToken.eImageFormat;

                this.chkAnimateLayers.Checked = VtfToken.bAnimateLayers;
                this.chkGenerateThumbnail.Checked = VtfToken.bGenerateThumbnail;

                this.chkGenerateMipmaps.Checked = VtfToken.bGenerateMipmaps;
                this.cboMipmapFilter.SelectedIndex = (int)VtfToken.eMipmapFilter;
                this.cboMipmapSharpenFilter.SelectedIndex = (int)VtfToken.eMipmapSharpenFilter;

                this.UpdateFlags(VtfToken, null);

                this.chkGenerateNormalmap.Checked = VtfToken.bGenerateNormalmap;
                this.cboNormalmapKernelFilter.SelectedIndex = (int)VtfToken.eNormalmapKernelFilter;
                this.cboNormalmapHeightConversionMethod.SelectedIndex = (int)VtfToken.eNormalmapHeightConversionMethod;
                this.cboNormalmapAlphaResult.SelectedIndex = (int)VtfToken.eNormalmapAlphaResult;
                this.numNormalmapScale.Value = VtfToken.fNormalmapScale;
                this.chkNormalmapWrap.Checked = VtfToken.bNormalmapWrap;

                this.cboVersion.Text = VtfToken.uiVersionMajor.ToString() + "." + VtfToken.uiVersionMinor.ToString();

                this.bUpdatingToken = false;
			}
			else
			{
                this.InitWidgetFromToken(new VtfSaveConfigToken());
			}
		}

        private unsafe void UpdateFlags(VtfSaveConfigToken Token, object sender)
        {
            VtfLib.ImageFormatInfo Info;
            if (VtfLib.vlImageGetImageFormatInfoEx(Token.eImageFormat, out Info))
            {
                if (Info.uiAlphaBitsPerPixel == 1)
                {
                    Token.uiImageFlags |= (uint)VtfLib.ImageFlag.ImageFlagOneBitAlpha;
                }
                else
                {
                    Token.uiImageFlags &= ~(uint)VtfLib.ImageFlag.ImageFlagOneBitAlpha;
                }
                if (Info.uiAlphaBitsPerPixel > 1)
                {
                    Token.uiImageFlags |= (uint)VtfLib.ImageFlag.ImageFlagEightBitAlpha;
                }
                else
                {
                    Token.uiImageFlags &= ~(uint)VtfLib.ImageFlag.ImageFlagEightBitAlpha;
                }
            }

            if (sender == this.chkGenerateMipmaps)
            {
                if (!this.chkGenerateMipmaps.Checked)
                {
                    Token.uiImageFlags |= (uint)VtfLib.ImageFlag.ImageFlagNoMIP;
                    Token.uiImageFlags |= (uint)VtfLib.ImageFlag.ImageFlagNoLOD;
                }
                else
                {
                    Token.uiImageFlags &= ~(uint)VtfLib.ImageFlag.ImageFlagNoMIP;
                    Token.uiImageFlags &= ~(uint)VtfLib.ImageFlag.ImageFlagNoLOD;
                }
            }

            if (sender == this.chkGenerateNormalmap)
            {
                if (this.chkGenerateNormalmap.Checked)
                {
                    Token.uiImageFlags |= (uint)VtfLib.ImageFlag.ImageFlagNormal;
                }
                else
                {
                    Token.uiImageFlags &= ~(uint)VtfLib.ImageFlag.ImageFlagNormal;
                }
            }

            this.bUpdatingFlags = true;
            for (int i = 0; i < (int)VtfLib.ImageFlag.ImageFlagCount; i++)
            {
                this.lstImageFlags.SetItemChecked(i, (Token.uiImageFlags & (uint)(1 << i)) != 0);
            }
            this.bUpdatingFlags = false;
        }

		private void InitializeComponent()
		{
            this.grpMipmaps = new System.Windows.Forms.GroupBox();
            this.cboMipmapSharpenFilter = new System.Windows.Forms.ComboBox();
            this.lblMipmapSharpenFilter = new System.Windows.Forms.Label();
            this.cboMipmapFilter = new System.Windows.Forms.ComboBox();
            this.lblMipmapFilter = new System.Windows.Forms.Label();
            this.chkGenerateMipmaps = new System.Windows.Forms.CheckBox();
            this.grpImageFlags = new System.Windows.Forms.GroupBox();
            this.lstImageFlags = new System.Windows.Forms.CheckedListBox();
            this.grpNormalmaps = new System.Windows.Forms.GroupBox();
            this.chkNormalmapWrap = new System.Windows.Forms.CheckBox();
            this.lblNormalmapScale = new System.Windows.Forms.Label();
            this.numNormalmapScale = new System.Windows.Forms.NumericUpDown();
            this.cboNormalmapAlphaResult = new System.Windows.Forms.ComboBox();
            this.lblNormalmapAlphaResult = new System.Windows.Forms.Label();
            this.cboNormalmapHeightConversionMethod = new System.Windows.Forms.ComboBox();
            this.lblNormalmapHeightConversionMethod = new System.Windows.Forms.Label();
            this.cboNormalmapKernelFilter = new System.Windows.Forms.ComboBox();
            this.lblNormalmapKernelFilter = new System.Windows.Forms.Label();
            this.chkGenerateNormalmap = new System.Windows.Forms.CheckBox();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabGeneral = new System.Windows.Forms.TabPage();
            this.grpGeneral = new System.Windows.Forms.GroupBox();
            this.chkAnimateLayers = new System.Windows.Forms.CheckBox();
            this.chkGenerateThumbnail = new System.Windows.Forms.CheckBox();
            this.grpImageFormat = new System.Windows.Forms.GroupBox();
            this.cboImageFormat = new System.Windows.Forms.ComboBox();
            this.grpTemplate = new System.Windows.Forms.GroupBox();
            this.cboTemplate = new System.Windows.Forms.ComboBox();
            this.tabMipmaps = new System.Windows.Forms.TabPage();
            this.tabFlags = new System.Windows.Forms.TabPage();
            this.tabNormalmap = new System.Windows.Forms.TabPage();
            this.tabAdvanced = new System.Windows.Forms.TabPage();
            this.grpVersion = new System.Windows.Forms.GroupBox();
            this.cboVersion = new System.Windows.Forms.ComboBox();
            this.grpMipmaps.SuspendLayout();
            this.grpImageFlags.SuspendLayout();
            this.grpNormalmaps.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNormalmapScale)).BeginInit();
            this.tabMain.SuspendLayout();
            this.tabGeneral.SuspendLayout();
            this.grpGeneral.SuspendLayout();
            this.grpImageFormat.SuspendLayout();
            this.grpTemplate.SuspendLayout();
            this.tabMipmaps.SuspendLayout();
            this.tabFlags.SuspendLayout();
            this.tabNormalmap.SuspendLayout();
            this.tabAdvanced.SuspendLayout();
            this.grpVersion.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpMipmaps
            // 
            this.grpMipmaps.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpMipmaps.Controls.Add(this.cboMipmapSharpenFilter);
            this.grpMipmaps.Controls.Add(this.lblMipmapSharpenFilter);
            this.grpMipmaps.Controls.Add(this.cboMipmapFilter);
            this.grpMipmaps.Controls.Add(this.lblMipmapFilter);
            this.grpMipmaps.Controls.Add(this.chkGenerateMipmaps);
            this.grpMipmaps.Location = new System.Drawing.Point(3, 6);
            this.grpMipmaps.Name = "grpMipmaps";
            this.grpMipmaps.Size = new System.Drawing.Size(162, 95);
            this.grpMipmaps.TabIndex = 0;
            this.grpMipmaps.TabStop = false;
            this.grpMipmaps.Text = "Mipmaps:";
            // 
            // cboMipmapSharpenFilter
            // 
            this.cboMipmapSharpenFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMipmapSharpenFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMipmapSharpenFilter.Enabled = false;
            this.cboMipmapSharpenFilter.FormattingEnabled = true;
            this.cboMipmapSharpenFilter.Items.AddRange(new object[] {
            "None",
            "Negative",
            "Lighter",
            "Darker",
            "Contrast More",
            "Contrast Less",
            "Smoothen",
            "Sharpen Soft",
            "Sharpen Medium",
            "Sharpen Strong",
            "Find Edges",
            "Contour",
            "Edge Detect",
            "Edge Detect Soft",
            "Emboss",
            "Mean Removal",
            "Unsharpen Mask",
            "XSharpen",
            "Wrap Sharp"});
            this.cboMipmapSharpenFilter.Location = new System.Drawing.Point(84, 70);
            this.cboMipmapSharpenFilter.Name = "cboMipmapSharpenFilter";
            this.cboMipmapSharpenFilter.Size = new System.Drawing.Size(72, 21);
            this.cboMipmapSharpenFilter.TabIndex = 4;
            this.cboMipmapSharpenFilter.SelectedIndexChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // lblMipmapSharpenFilter
            // 
            this.lblMipmapSharpenFilter.AutoSize = true;
            this.lblMipmapSharpenFilter.Location = new System.Drawing.Point(6, 73);
            this.lblMipmapSharpenFilter.Name = "lblMipmapSharpenFilter";
            this.lblMipmapSharpenFilter.Size = new System.Drawing.Size(75, 13);
            this.lblMipmapSharpenFilter.TabIndex = 3;
            this.lblMipmapSharpenFilter.Text = "Sharpen Filter:";
            // 
            // cboMipmapFilter
            // 
            this.cboMipmapFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMipmapFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMipmapFilter.Enabled = false;
            this.cboMipmapFilter.FormattingEnabled = true;
            this.cboMipmapFilter.Items.AddRange(new object[] {
            "Point",
            "Box",
            "Triangle",
            "Quadratic",
            "Cubic",
            "Catrom",
            "Mitchell",
            "Gaussian",
            "Sine Cardinal",
            "Bessel",
            "Hanning",
            "Hamming",
            "Blackman",
            "Kaiser"});
            this.cboMipmapFilter.Location = new System.Drawing.Point(84, 43);
            this.cboMipmapFilter.Name = "cboMipmapFilter";
            this.cboMipmapFilter.Size = new System.Drawing.Size(72, 21);
            this.cboMipmapFilter.TabIndex = 2;
            this.cboMipmapFilter.SelectedIndexChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // lblMipmapFilter
            // 
            this.lblMipmapFilter.AutoSize = true;
            this.lblMipmapFilter.Location = new System.Drawing.Point(6, 46);
            this.lblMipmapFilter.Name = "lblMipmapFilter";
            this.lblMipmapFilter.Size = new System.Drawing.Size(72, 13);
            this.lblMipmapFilter.TabIndex = 1;
            this.lblMipmapFilter.Text = "Mipmap Filter:";
            // 
            // chkGenerateMipmaps
            // 
            this.chkGenerateMipmaps.AutoSize = true;
            this.chkGenerateMipmaps.Location = new System.Drawing.Point(7, 20);
            this.chkGenerateMipmaps.Name = "chkGenerateMipmaps";
            this.chkGenerateMipmaps.Size = new System.Drawing.Size(115, 17);
            this.chkGenerateMipmaps.TabIndex = 0;
            this.chkGenerateMipmaps.Text = "Generate Mipmaps";
            this.chkGenerateMipmaps.UseVisualStyleBackColor = true;
            this.chkGenerateMipmaps.CheckedChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // grpImageFlags
            // 
            this.grpImageFlags.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpImageFlags.Controls.Add(this.lstImageFlags);
            this.grpImageFlags.Location = new System.Drawing.Point(3, 6);
            this.grpImageFlags.Name = "grpImageFlags";
            this.grpImageFlags.Size = new System.Drawing.Size(162, 174);
            this.grpImageFlags.TabIndex = 0;
            this.grpImageFlags.TabStop = false;
            this.grpImageFlags.Text = "Flags:";
            // 
            // lstImageFlags
            // 
            this.lstImageFlags.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstImageFlags.CheckOnClick = true;
            this.lstImageFlags.FormattingEnabled = true;
            this.lstImageFlags.Items.AddRange(new object[] {
            "Point Sample",
            "Trilinear",
            "Clamp S",
            "Clamp T",
            "Anisotropic",
            "Hint DXT5",
            "SRGB",
            "Normal Map",
            "No Mipmap",
            "No Level Of Detail",
            "No Minimum Mipmap",
            "Procedural",
            "One Bit Alpha (Format Specific)",
            "Eight Bit Alpha (Format Specific)",
            "Enviroment Map (Format Specific)",
            "Render Target",
            "Depth Render Target",
            "No Debug Override",
            "Single Copy",
            "Unused",
            "Unused",
            "Unused",
            "Unused",
            "No Depth Buffer",
            "Unused",
            "Clamp U",
            "Vertex Texture",
            "SSBump",
            "Unused",
            "Clamp All"});
            this.lstImageFlags.Location = new System.Drawing.Point(6, 19);
            this.lstImageFlags.Name = "lstImageFlags";
            this.lstImageFlags.Size = new System.Drawing.Size(150, 139);
            this.lstImageFlags.TabIndex = 0;
            this.lstImageFlags.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.lstImageFlags_ItemCheck);
            // 
            // grpNormalmaps
            // 
            this.grpNormalmaps.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpNormalmaps.Controls.Add(this.chkNormalmapWrap);
            this.grpNormalmaps.Controls.Add(this.lblNormalmapScale);
            this.grpNormalmaps.Controls.Add(this.numNormalmapScale);
            this.grpNormalmaps.Controls.Add(this.cboNormalmapAlphaResult);
            this.grpNormalmaps.Controls.Add(this.lblNormalmapAlphaResult);
            this.grpNormalmaps.Controls.Add(this.cboNormalmapHeightConversionMethod);
            this.grpNormalmaps.Controls.Add(this.lblNormalmapHeightConversionMethod);
            this.grpNormalmaps.Controls.Add(this.cboNormalmapKernelFilter);
            this.grpNormalmaps.Controls.Add(this.lblNormalmapKernelFilter);
            this.grpNormalmaps.Controls.Add(this.chkGenerateNormalmap);
            this.grpNormalmaps.Location = new System.Drawing.Point(3, 6);
            this.grpNormalmaps.Name = "grpNormalmaps";
            this.grpNormalmaps.Size = new System.Drawing.Size(162, 173);
            this.grpNormalmaps.TabIndex = 0;
            this.grpNormalmaps.TabStop = false;
            this.grpNormalmaps.Text = "Normal Maps:";
            // 
            // chkNormalmapWrap
            // 
            this.chkNormalmapWrap.AutoSize = true;
            this.chkNormalmapWrap.Enabled = false;
            this.chkNormalmapWrap.Location = new System.Drawing.Point(9, 149);
            this.chkNormalmapWrap.Name = "chkNormalmapWrap";
            this.chkNormalmapWrap.Size = new System.Drawing.Size(112, 17);
            this.chkNormalmapWrap.TabIndex = 9;
            this.chkNormalmapWrap.Text = "Wrap Normal Map";
            this.chkNormalmapWrap.UseVisualStyleBackColor = true;
            this.chkNormalmapWrap.CheckedChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // lblNormalmapScale
            // 
            this.lblNormalmapScale.AutoSize = true;
            this.lblNormalmapScale.Location = new System.Drawing.Point(6, 125);
            this.lblNormalmapScale.Name = "lblNormalmapScale";
            this.lblNormalmapScale.Size = new System.Drawing.Size(37, 13);
            this.lblNormalmapScale.TabIndex = 7;
            this.lblNormalmapScale.Text = "Scale:";
            // 
            // numNormalmapScale
            // 
            this.numNormalmapScale.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.numNormalmapScale.DecimalPlaces = 4;
            this.numNormalmapScale.Enabled = false;
            this.numNormalmapScale.Increment = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            this.numNormalmapScale.Location = new System.Drawing.Point(84, 123);
            this.numNormalmapScale.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.numNormalmapScale.Name = "numNormalmapScale";
            this.numNormalmapScale.Size = new System.Drawing.Size(72, 20);
            this.numNormalmapScale.TabIndex = 8;
            this.numNormalmapScale.ValueChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // cboNormalmapAlphaResult
            // 
            this.cboNormalmapAlphaResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboNormalmapAlphaResult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNormalmapAlphaResult.Enabled = false;
            this.cboNormalmapAlphaResult.FormattingEnabled = true;
            this.cboNormalmapAlphaResult.Items.AddRange(new object[] {
            "No Change",
            "Set To Height",
            "Set To Black",
            "Set To White"});
            this.cboNormalmapAlphaResult.Location = new System.Drawing.Point(84, 96);
            this.cboNormalmapAlphaResult.Name = "cboNormalmapAlphaResult";
            this.cboNormalmapAlphaResult.Size = new System.Drawing.Size(72, 21);
            this.cboNormalmapAlphaResult.TabIndex = 6;
            this.cboNormalmapAlphaResult.SelectedIndexChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // lblNormalmapAlphaResult
            // 
            this.lblNormalmapAlphaResult.AutoSize = true;
            this.lblNormalmapAlphaResult.Location = new System.Drawing.Point(6, 99);
            this.lblNormalmapAlphaResult.Name = "lblNormalmapAlphaResult";
            this.lblNormalmapAlphaResult.Size = new System.Drawing.Size(70, 13);
            this.lblNormalmapAlphaResult.TabIndex = 5;
            this.lblNormalmapAlphaResult.Text = "Alpha Result:";
            // 
            // cboNormalmapHeightConversionMethod
            // 
            this.cboNormalmapHeightConversionMethod.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboNormalmapHeightConversionMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNormalmapHeightConversionMethod.Enabled = false;
            this.cboNormalmapHeightConversionMethod.FormattingEnabled = true;
            this.cboNormalmapHeightConversionMethod.Items.AddRange(new object[] {
            "Alpha Channel",
            "Average RGB",
            "Biased RGB",
            "Red Channel",
            "Green  Channel",
            "Blue  Channel",
            "Max RGB",
            "Colorspace"});
            this.cboNormalmapHeightConversionMethod.Location = new System.Drawing.Point(84, 69);
            this.cboNormalmapHeightConversionMethod.Name = "cboNormalmapHeightConversionMethod";
            this.cboNormalmapHeightConversionMethod.Size = new System.Drawing.Size(72, 21);
            this.cboNormalmapHeightConversionMethod.TabIndex = 4;
            this.cboNormalmapHeightConversionMethod.SelectedIndexChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // lblNormalmapHeightConversionMethod
            // 
            this.lblNormalmapHeightConversionMethod.AutoSize = true;
            this.lblNormalmapHeightConversionMethod.Location = new System.Drawing.Point(6, 72);
            this.lblNormalmapHeightConversionMethod.Name = "lblNormalmapHeightConversionMethod";
            this.lblNormalmapHeightConversionMethod.Size = new System.Drawing.Size(78, 13);
            this.lblNormalmapHeightConversionMethod.TabIndex = 3;
            this.lblNormalmapHeightConversionMethod.Text = "Height Source:";
            // 
            // cboNormalmapKernelFilter
            // 
            this.cboNormalmapKernelFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboNormalmapKernelFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNormalmapKernelFilter.Enabled = false;
            this.cboNormalmapKernelFilter.FormattingEnabled = true;
            this.cboNormalmapKernelFilter.Items.AddRange(new object[] {
            "4 Sample",
            "3x3",
            "5x5",
            "7x7",
            "9x9",
            "DuDv"});
            this.cboNormalmapKernelFilter.Location = new System.Drawing.Point(84, 42);
            this.cboNormalmapKernelFilter.Name = "cboNormalmapKernelFilter";
            this.cboNormalmapKernelFilter.Size = new System.Drawing.Size(72, 21);
            this.cboNormalmapKernelFilter.TabIndex = 2;
            this.cboNormalmapKernelFilter.SelectedIndexChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // lblNormalmapKernelFilter
            // 
            this.lblNormalmapKernelFilter.AutoSize = true;
            this.lblNormalmapKernelFilter.Location = new System.Drawing.Point(6, 45);
            this.lblNormalmapKernelFilter.Name = "lblNormalmapKernelFilter";
            this.lblNormalmapKernelFilter.Size = new System.Drawing.Size(65, 13);
            this.lblNormalmapKernelFilter.TabIndex = 1;
            this.lblNormalmapKernelFilter.Text = "Kernel Filter:";
            // 
            // chkGenerateNormalmap
            // 
            this.chkGenerateNormalmap.AutoSize = true;
            this.chkGenerateNormalmap.Location = new System.Drawing.Point(6, 19);
            this.chkGenerateNormalmap.Name = "chkGenerateNormalmap";
            this.chkGenerateNormalmap.Size = new System.Drawing.Size(130, 17);
            this.chkGenerateNormalmap.TabIndex = 0;
            this.chkGenerateNormalmap.Text = "Generate Normal Map";
            this.chkGenerateNormalmap.UseVisualStyleBackColor = true;
            this.chkGenerateNormalmap.CheckedChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabGeneral);
            this.tabMain.Controls.Add(this.tabMipmaps);
            this.tabMain.Controls.Add(this.tabFlags);
            this.tabMain.Controls.Add(this.tabNormalmap);
            this.tabMain.Controls.Add(this.tabAdvanced);
            this.tabMain.Location = new System.Drawing.Point(0, 3);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(176, 209);
            this.tabMain.TabIndex = 0;
            // 
            // tabGeneral
            // 
            this.tabGeneral.Controls.Add(this.grpGeneral);
            this.tabGeneral.Controls.Add(this.grpImageFormat);
            this.tabGeneral.Controls.Add(this.grpTemplate);
            this.tabGeneral.Location = new System.Drawing.Point(4, 22);
            this.tabGeneral.Name = "tabGeneral";
            this.tabGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.tabGeneral.Size = new System.Drawing.Size(168, 183);
            this.tabGeneral.TabIndex = 3;
            this.tabGeneral.Text = "General";
            this.tabGeneral.UseVisualStyleBackColor = true;
            // 
            // grpGeneral
            // 
            this.grpGeneral.Controls.Add(this.chkAnimateLayers);
            this.grpGeneral.Controls.Add(this.chkGenerateThumbnail);
            this.grpGeneral.Location = new System.Drawing.Point(6, 108);
            this.grpGeneral.Name = "grpGeneral";
            this.grpGeneral.Size = new System.Drawing.Size(159, 64);
            this.grpGeneral.TabIndex = 2;
            this.grpGeneral.TabStop = false;
            this.grpGeneral.Text = "General:";
            // 
            // chkAnimateLayers
            // 
            this.chkAnimateLayers.AutoSize = true;
            this.chkAnimateLayers.Location = new System.Drawing.Point(6, 19);
            this.chkAnimateLayers.Name = "chkAnimateLayers";
            this.chkAnimateLayers.Size = new System.Drawing.Size(98, 17);
            this.chkAnimateLayers.TabIndex = 0;
            this.chkAnimateLayers.Text = "Animate Layers";
            this.chkAnimateLayers.UseVisualStyleBackColor = true;
            this.chkAnimateLayers.CheckedChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // chkGenerateThumbnail
            // 
            this.chkGenerateThumbnail.AutoSize = true;
            this.chkGenerateThumbnail.Location = new System.Drawing.Point(6, 42);
            this.chkGenerateThumbnail.Name = "chkGenerateThumbnail";
            this.chkGenerateThumbnail.Size = new System.Drawing.Size(122, 17);
            this.chkGenerateThumbnail.TabIndex = 1;
            this.chkGenerateThumbnail.Text = "Generate Thumbnail";
            this.chkGenerateThumbnail.UseVisualStyleBackColor = true;
            this.chkGenerateThumbnail.CheckedChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // grpImageFormat
            // 
            this.grpImageFormat.Controls.Add(this.cboImageFormat);
            this.grpImageFormat.Location = new System.Drawing.Point(3, 57);
            this.grpImageFormat.Name = "grpImageFormat";
            this.grpImageFormat.Size = new System.Drawing.Size(162, 45);
            this.grpImageFormat.TabIndex = 1;
            this.grpImageFormat.TabStop = false;
            this.grpImageFormat.Text = "Image Format:";
            // 
            // cboImageFormat
            // 
            this.cboImageFormat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboImageFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboImageFormat.FormattingEnabled = true;
            this.cboImageFormat.Items.AddRange(new object[] {
            "RGBA8888",
            "ABGR8888 (Common)",
            "RGB888",
            "BGR888 (Common)",
            "RGB565",
            "I8",
            "IA88",
            "P8 (Not supported)",
            "A8",
            "RGB888 Bluescreen",
            "BGR888 Bluescreen",
            "ARGB8888",
            "BGRA8888",
            "DXT1 (Common)",
            "DXT3",
            "DXT5 (Common)",
            "BGRX8888",
            "BGR565",
            "BGRX5551",
            "BGRA4444",
            "DXT1 With One Bit Alpha",
            "BGRA5551",
            "UV88 (Common)",
            "UVWQ8888",
            "RGBA16161616F",
            "RGBA16161616",
            "UVLX8888"});
            this.cboImageFormat.Location = new System.Drawing.Point(9, 19);
            this.cboImageFormat.Name = "cboImageFormat";
            this.cboImageFormat.Size = new System.Drawing.Size(147, 21);
            this.cboImageFormat.TabIndex = 0;
            this.cboImageFormat.SelectedIndexChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // grpTemplate
            // 
            this.grpTemplate.Controls.Add(this.cboTemplate);
            this.grpTemplate.Location = new System.Drawing.Point(3, 6);
            this.grpTemplate.Name = "grpTemplate";
            this.grpTemplate.Size = new System.Drawing.Size(162, 45);
            this.grpTemplate.TabIndex = 0;
            this.grpTemplate.TabStop = false;
            this.grpTemplate.Text = "Template:";
            // 
            // cboTemplate
            // 
            this.cboTemplate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboTemplate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTemplate.FormattingEnabled = true;
            this.cboTemplate.Items.AddRange(new object[] {
            "Compressed Texture",
            "Compressed Texture With Alpha",
            "DuDv Map",
            "Generate DuDv Map",
            "Generate Normal Map",
            "Generate Normal Map With Alpha",
            "Generic (Default)",
            "Normal Map",
            "Normal Map With Alpha",
            "Sky",
            "Spray",
            "Spray With Alpha",
            "Uncompressed Texture",
            "Uncompressed Texture With Alpha"});
            this.cboTemplate.Location = new System.Drawing.Point(9, 18);
            this.cboTemplate.Name = "cboTemplate";
            this.cboTemplate.Size = new System.Drawing.Size(147, 21);
            this.cboTemplate.TabIndex = 0;
            this.cboTemplate.SelectedIndexChanged += new System.EventHandler(this.cboTemplate_SelectedIndexChanged);
            // 
            // tabMipmaps
            // 
            this.tabMipmaps.Controls.Add(this.grpMipmaps);
            this.tabMipmaps.Location = new System.Drawing.Point(4, 22);
            this.tabMipmaps.Name = "tabMipmaps";
            this.tabMipmaps.Padding = new System.Windows.Forms.Padding(3);
            this.tabMipmaps.Size = new System.Drawing.Size(168, 183);
            this.tabMipmaps.TabIndex = 0;
            this.tabMipmaps.Text = "Mipmaps";
            this.tabMipmaps.UseVisualStyleBackColor = true;
            // 
            // tabFlags
            // 
            this.tabFlags.Controls.Add(this.grpImageFlags);
            this.tabFlags.Location = new System.Drawing.Point(4, 22);
            this.tabFlags.Name = "tabFlags";
            this.tabFlags.Padding = new System.Windows.Forms.Padding(3);
            this.tabFlags.Size = new System.Drawing.Size(168, 183);
            this.tabFlags.TabIndex = 1;
            this.tabFlags.Text = "Flags";
            this.tabFlags.UseVisualStyleBackColor = true;
            // 
            // tabNormalmap
            // 
            this.tabNormalmap.Controls.Add(this.grpNormalmaps);
            this.tabNormalmap.Location = new System.Drawing.Point(4, 22);
            this.tabNormalmap.Name = "tabNormalmap";
            this.tabNormalmap.Size = new System.Drawing.Size(168, 183);
            this.tabNormalmap.TabIndex = 2;
            this.tabNormalmap.Text = "Normals";
            this.tabNormalmap.UseVisualStyleBackColor = true;
            // 
            // tabAdvanced
            // 
            this.tabAdvanced.Controls.Add(this.grpVersion);
            this.tabAdvanced.Location = new System.Drawing.Point(4, 22);
            this.tabAdvanced.Name = "tabAdvanced";
            this.tabAdvanced.Size = new System.Drawing.Size(168, 183);
            this.tabAdvanced.TabIndex = 4;
            this.tabAdvanced.Text = "Advanced";
            this.tabAdvanced.UseVisualStyleBackColor = true;
            // 
            // grpVersion
            // 
            this.grpVersion.Controls.Add(this.cboVersion);
            this.grpVersion.Location = new System.Drawing.Point(3, 6);
            this.grpVersion.Name = "grpVersion";
            this.grpVersion.Size = new System.Drawing.Size(162, 45);
            this.grpVersion.TabIndex = 0;
            this.grpVersion.TabStop = false;
            this.grpVersion.Text = "Version:";
            // 
            // cboVersion
            // 
            this.cboVersion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVersion.FormattingEnabled = true;
            this.cboVersion.Items.AddRange(new object[] {
            "7.5",
            "7.4",
            "7.3",
            "7.2",
            "7.1",
            "7.0"});
            this.cboVersion.Location = new System.Drawing.Point(9, 18);
            this.cboVersion.Name = "cboVersion";
            this.cboVersion.Size = new System.Drawing.Size(147, 21);
            this.cboVersion.TabIndex = 0;
            this.cboVersion.SelectedIndexChanged += new System.EventHandler(this.VtfSaveConfigWidget_ControlChanged);
            // 
            // VtfSaveConfigWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.Controls.Add(this.tabMain);
            this.Name = "VtfSaveConfigWidget";
            this.Size = new System.Drawing.Size(176, 211);
            this.grpMipmaps.ResumeLayout(false);
            this.grpMipmaps.PerformLayout();
            this.grpImageFlags.ResumeLayout(false);
            this.grpNormalmaps.ResumeLayout(false);
            this.grpNormalmaps.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNormalmapScale)).EndInit();
            this.tabMain.ResumeLayout(false);
            this.tabGeneral.ResumeLayout(false);
            this.grpGeneral.ResumeLayout(false);
            this.grpGeneral.PerformLayout();
            this.grpImageFormat.ResumeLayout(false);
            this.grpTemplate.ResumeLayout(false);
            this.tabMipmaps.ResumeLayout(false);
            this.tabFlags.ResumeLayout(false);
            this.tabNormalmap.ResumeLayout(false);
            this.tabAdvanced.ResumeLayout(false);
            this.grpVersion.ResumeLayout(false);
            this.ResumeLayout(false);

		}

        private void cboTemplate_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.token = new VtfSaveConfigToken((VtfSaveConfigTemplate)this.cboTemplate.SelectedIndex);
            this.InitWidgetFromToken(this.token);
            this.UpdateToken();
        }

        private void VtfSaveConfigWidget_ControlChanged(object sender, EventArgs e)
        {
            if (!this.bUpdatingToken)
            {
                this.UpdateToken();
            }

            if (sender == this.cboImageFormat || sender == this.chkGenerateMipmaps || sender == this.chkGenerateNormalmap || sender == this.cboNormalmapKernelFilter)
            {
                if (!this.bUpdatingToken)
                {
                    this.UpdateFlags((VtfSaveConfigToken)this.token, sender);
                }
            }

            if (sender == this.chkGenerateMipmaps)
            {
                this.cboMipmapFilter.Enabled = this.chkGenerateMipmaps.Checked;
                this.cboMipmapSharpenFilter.Enabled = this.chkGenerateMipmaps.Checked;
            }
            else if (sender == this.chkGenerateNormalmap)
            {
                this.cboNormalmapKernelFilter.Enabled = this.chkGenerateNormalmap.Checked;
                this.cboNormalmapHeightConversionMethod.Enabled = this.chkGenerateNormalmap.Checked;
                this.cboNormalmapAlphaResult.Enabled = this.chkGenerateNormalmap.Checked;
                this.numNormalmapScale.Enabled = this.chkGenerateNormalmap.Checked;
                this.chkNormalmapWrap.Enabled = this.chkGenerateNormalmap.Checked;
            }
        }

        private void lstImageFlags_ItemCheck(object sender, System.Windows.Forms.ItemCheckEventArgs e)
        {
            if (!this.bUpdatingFlags)
            {
                if (e.Index == 12 || e.Index == 13 || e.Index == 14 || (string)this.lstImageFlags.Items[e.Index] == "Unused")
                {
                    e.NewValue = e.CurrentValue;
                    return;
                }

                if (!this.bUpdatingToken)
                {
                    this.UpdateToken();
                }
            }
        }
	}
}
