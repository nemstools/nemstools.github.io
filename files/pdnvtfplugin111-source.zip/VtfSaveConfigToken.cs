using System;
using PaintDotNet;

namespace VtfFileTypePlugin
{
    internal enum VtfSaveConfigTemplate
    {
        VtfTemplateCompressedTexture = 0,
        VtfTemplateCompressedTextureWithAlpha,
        VtfTemplateDuDvMap,
        VtfTemplateGenerateDuDvMap,
        VtfTemplateGenerateNormalMap,
        VtfTemplateGenerateNormalMapWithAlpha,
        VtfTemplateGeneric,
        VtfTemplateNormalMap,
        VtfTemplateNormalMapWithAlpha,
        VtfTemplateSky,
        VtfTemplateSpray,
        VtfTemplateSprayWithAlpha,
        VtfTemplateUncompressedTexture,
        VtfTemplateUncompressedTextureWithAlpha
    }

	[Serializable]
    internal class VtfSaveConfigToken : SaveConfigToken
	{
        public VtfLib.ImageFormat eImageFormat;
        public uint uiImageFlags;

        public bool bGenerateMipmaps;
        public VtfLib.MipmapFilter eMipmapFilter;
        public VtfLib.SharpenFilter eMipmapSharpenFilter;

        public bool bAnimateLayers;
        public bool bGenerateThumbnail;

        public bool bGenerateNormalmap;
        public VtfLib.KernelFilter eNormalmapKernelFilter;
        public VtfLib.HeightConversionMethod eNormalmapHeightConversionMethod;
        public VtfLib.NormalAlphaResult eNormalmapAlphaResult;
        public decimal fNormalmapScale;
        public bool bNormalmapWrap;

        public uint uiVersionMajor;
        public uint uiVersionMinor;

    	public VtfSaveConfigToken()
		{
            this.eImageFormat = VtfLib.ImageFormat.ImageFormatABGR8888;
            this.uiImageFlags = 0;

            this.bGenerateMipmaps = true;
            this.eMipmapFilter = VtfLib.MipmapFilter.MipmapFilterBox;
            this.eMipmapSharpenFilter = VtfLib.SharpenFilter.SharpenFilterSharpenSoft;

            this.bAnimateLayers = false;
            this.bGenerateThumbnail = true;

            this.bGenerateNormalmap = false;
            this.eNormalmapKernelFilter = VtfLib.KernelFilter.KernelFilter3x3;
            this.eNormalmapHeightConversionMethod = VtfLib.HeightConversionMethod.HeightConversionMethodAverageRGB;
            this.eNormalmapAlphaResult = VtfLib.NormalAlphaResult.NormalAlphaResultNoChange;
            this.fNormalmapScale = (decimal)2.0;
            this.bNormalmapWrap = false;

            this.uiVersionMajor = 7;
            this.uiVersionMinor = 2;
		}

        public VtfSaveConfigToken(VtfSaveConfigTemplate Template)
        {
            this.eImageFormat = VtfLib.ImageFormat.ImageFormatABGR8888;
            this.uiImageFlags = 0;

            this.bGenerateMipmaps = true;
            this.eMipmapFilter = VtfLib.MipmapFilter.MipmapFilterBox;
            this.eMipmapSharpenFilter = VtfLib.SharpenFilter.SharpenFilterSharpenSoft;

            this.bAnimateLayers = false;
            this.bGenerateThumbnail = true;

            this.bGenerateNormalmap = false;
            this.eNormalmapKernelFilter = VtfLib.KernelFilter.KernelFilter3x3;
            this.eNormalmapHeightConversionMethod = VtfLib.HeightConversionMethod.HeightConversionMethodAverageRGB;
            this.eNormalmapAlphaResult = VtfLib.NormalAlphaResult.NormalAlphaResultNoChange;
            this.fNormalmapScale = (decimal)2.0;
            this.bNormalmapWrap = false;

            switch (Template)
            {
                case VtfSaveConfigTemplate.VtfTemplateCompressedTexture:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatDXT1;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagNone;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateCompressedTextureWithAlpha:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatDXT5;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagNone;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateDuDvMap:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatUV88;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagTrilinear;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateGenerateDuDvMap:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatUV88;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagTrilinear;

                    this.bGenerateNormalmap = true;
                    this.eNormalmapKernelFilter = VtfLib.KernelFilter.KernelFilterDuDv;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateGenerateNormalMap:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatBGR888;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagTrilinear | (uint)VtfLib.ImageFlag.ImageFlagNormal;

                    this.bGenerateNormalmap = true;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateGenerateNormalMapWithAlpha:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatBGRA8888;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagTrilinear | (uint)VtfLib.ImageFlag.ImageFlagNormal;

                    this.bGenerateNormalmap = true;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateGeneric:
                    break;
                case VtfSaveConfigTemplate.VtfTemplateNormalMap:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatBGR888;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagTrilinear | (uint)VtfLib.ImageFlag.ImageFlagNormal;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateNormalMapWithAlpha:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatBGRA8888;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagTrilinear | (uint)VtfLib.ImageFlag.ImageFlagNormal;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateSky:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatDXT5;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagClampS | (uint)VtfLib.ImageFlag.ImageFlagClampT | (uint)VtfLib.ImageFlag.ImageFlagHintDXT5 | (uint)VtfLib.ImageFlag.ImageFlagNoMIP;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateSpray:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatDXT1;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagClampS | (uint)VtfLib.ImageFlag.ImageFlagClampT | (uint)VtfLib.ImageFlag.ImageFlagNoMIP | (uint)VtfLib.ImageFlag.ImageFlagNoLOD;

                    this.bGenerateMipmaps = false;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateSprayWithAlpha:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatDXT5;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagClampS | (uint)VtfLib.ImageFlag.ImageFlagClampT | (uint)VtfLib.ImageFlag.ImageFlagNoMIP | (uint)VtfLib.ImageFlag.ImageFlagNoLOD;

                    this.bGenerateMipmaps = false;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateUncompressedTexture:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatBGR888;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagNone;
                    break;
                case VtfSaveConfigTemplate.VtfTemplateUncompressedTextureWithAlpha:
                    this.eImageFormat = VtfLib.ImageFormat.ImageFormatBGRA8888;
                    this.uiImageFlags = (uint)VtfLib.ImageFlag.ImageFlagNone;
                    break;
            }
        }

        protected VtfSaveConfigToken(VtfSaveConfigToken Token)
		{
            this.eImageFormat = Token.eImageFormat;
            this.uiImageFlags = Token.uiImageFlags;

            this.bGenerateMipmaps = Token.bGenerateMipmaps;
            this.eMipmapFilter = Token.eMipmapFilter;
            this.eMipmapSharpenFilter = Token.eMipmapSharpenFilter;

            this.bAnimateLayers = Token.bAnimateLayers;
            this.bGenerateThumbnail = Token.bGenerateThumbnail;

            this.bGenerateNormalmap = Token.bGenerateNormalmap;
            this.eNormalmapKernelFilter = Token.eNormalmapKernelFilter;
            this.eNormalmapHeightConversionMethod = Token.eNormalmapHeightConversionMethod;
            this.eNormalmapAlphaResult = Token.eNormalmapAlphaResult;
            this.fNormalmapScale = Token.fNormalmapScale;
            this.bNormalmapWrap = Token.bNormalmapWrap;

            this.uiVersionMajor = Token.uiVersionMajor;
            this.uiVersionMinor = Token.uiVersionMinor;
		}

        public override object Clone()
        {
            return new VtfSaveConfigToken(this);
        }

        public unsafe VtfLib.CreateOptions GetCreateOptions()
		{
            VtfLib.CreateOptions CreateOptions;
            VtfLib.vlImageCreateDefaultCreateStructure(out CreateOptions);

            CreateOptions.uiVersionMajor = this.uiVersionMajor;
            CreateOptions.uiVersionMinor = this.uiVersionMinor;

			CreateOptions.eImageFormat = this.eImageFormat;
            CreateOptions.uiFlags = this.uiImageFlags;

            CreateOptions.bMipmaps = this.bGenerateMipmaps;
            CreateOptions.eMipmapFilter = this.eMipmapFilter;
            CreateOptions.eSharpenFilter = this.eMipmapSharpenFilter;

            CreateOptions.bThumbnail = this.bGenerateThumbnail;

            CreateOptions.bResize = true;

            CreateOptions.bNormalMap = this.bGenerateNormalmap;
            CreateOptions.eKernelFilter = this.eNormalmapKernelFilter;
            CreateOptions.eHeightConversionMethod = this.eNormalmapHeightConversionMethod;
            CreateOptions.eNormalAlphaResult = this.eNormalmapAlphaResult;
            CreateOptions.fBumpScale = (float)this.fNormalmapScale;
            CreateOptions.bNormalWrap = this.bNormalmapWrap;

			return CreateOptions;
		}

		public override void Validate()
		{
			if (this.eImageFormat == VtfLib.ImageFormat.ImageFormatNone || this.eImageFormat >= VtfLib.ImageFormat.ImageFormatCount)
			{
                throw new ArgumentOutOfRangeException("Unrecognised image format (" + this.eImageFormat + ").");
			}

            if (this.eMipmapFilter >= VtfLib.MipmapFilter.MipmapFilterCount)
            {
                throw new ArgumentOutOfRangeException("Unrecognised mipmap filter (" + this.eMipmapFilter + ").");
            }

            if (this.eMipmapSharpenFilter >= VtfLib.SharpenFilter.SharpenFilterCount)
            {
                throw new ArgumentOutOfRangeException("Unrecognised mipmap sharpen filter (" + this.eMipmapSharpenFilter + ").");
            }

            if (this.eNormalmapKernelFilter >= VtfLib.KernelFilter.KernelFilterCount)
            {
                throw new ArgumentOutOfRangeException("Unrecognised normal kernel filter (" + this.eNormalmapKernelFilter + ").");
            }

            if (this.eNormalmapHeightConversionMethod >= VtfLib.HeightConversionMethod.HeightConversionMethodCount)
            {
                throw new ArgumentOutOfRangeException("Unrecognised normal height conversion method (" + this.eNormalmapHeightConversionMethod + ").");
            }

            if (this.eNormalmapAlphaResult >= VtfLib.NormalAlphaResult.NormalAlphaResultCount)
            {
                throw new ArgumentOutOfRangeException("Unrecognised normal alpha result (" + this.eNormalmapAlphaResult + ").");
            }

            if (this.fNormalmapScale <= 0)
            {
                throw new ArgumentOutOfRangeException("Invalid normal scale (" + this.fNormalmapScale + ").");
            }

            if (this.uiVersionMajor != VtfLib.uiMajorVersion || this.uiVersionMinor > VtfLib.uiMinorVersion)
            {
                throw new ArgumentOutOfRangeException("Invalid VTF version (" + this.uiVersionMajor + "." + this.uiVersionMinor + ").");
            }
		}
	}
}
