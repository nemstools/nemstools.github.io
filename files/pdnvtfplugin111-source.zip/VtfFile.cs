using System;
using PaintDotNet;

namespace VtfFileTypePlugin
{
	internal class VtfFile
	{
        public VtfFile()
		{

		}

        public unsafe void Save(System.IO.Stream Output, Document Input, VtfSaveConfigToken Token, Surface ScratchSurface)
		{
            uint uiImage;
            VtfLib.vlCreateImage(&uiImage);
            VtfLib.vlBindImage(uiImage);

            try
            {
                VtfLib.CreateOptions CreateOptions = Token.GetCreateOptions();

                int iVisibleLayers = 0;
                for (int i = 0; i < Input.Layers.Count; i++)
                {
                    if (((Layer)Input.Layers[i]).Visible)
                    {
                        iVisibleLayers++;
                    }
                }

                if (!Token.bAnimateLayers || iVisibleLayers <= 1)
                {
                    using (Surface Surface = new Surface(Input.Width, Input.Height))
                    {
                        Surface.Clear(ColorBgra.Transparent);

                        using (RenderArgs RenderArgs = new RenderArgs(Surface))
                        {
                            Input.Render(RenderArgs, true);
                        }

                    //using (Surface Surface = ScratchSurface)
                    //{
                        byte[] lpImageData = new byte[Surface.Width * Surface.Height * 4];

                        uint uiIndex = 0;
                        for (int y = 0; y < Surface.Height; y++)
                        {
                            for (int x = 0; x < Surface.Width; x++)
                            {
                                ColorBgra Color = Surface.GetPoint(x, y);

                                lpImageData[uiIndex++] = Color.R;
                                lpImageData[uiIndex++] = Color.G;
                                lpImageData[uiIndex++] = Color.B;
                                lpImageData[uiIndex++] = Color.A;
                            }
                        }

                        fixed (byte* lpBuffer = lpImageData)
                        {
                            if (!VtfLib.vlImageCreateSingle((uint)Surface.Width, (uint)Surface.Height, lpBuffer, ref CreateOptions))
                            {
                                throw new FormatException(VtfLib.vlGetLastError());
                            }
                        }
                    }
                }
                else
                {
                    byte** lpFrameData = stackalloc byte*[iVisibleLayers];
                    byte[] lpImageData = new byte[Input.Width * Input.Height * 4 * iVisibleLayers];

                    fixed (byte* lpBuffer = lpImageData)
                    {
                        int iVisibleLayerIndex = 0;
                        for (int i = 0; i < Input.Layers.Count; i++)
                        {
                            Layer Layer = (Layer)Input.Layers[i];

                            if (!Layer.Visible)
                            {
                                continue;
                            }

                            using (Surface Surface = new Surface(Input.Width, Input.Height))
                            {
                                Surface.Clear(ColorBgra.Transparent);

                                using (RenderArgs RenderArgs = new RenderArgs(Surface))
                                {
                                    Layer.Render(RenderArgs, new System.Drawing.Rectangle(0, 0, Input.Width, Input.Height));
                                }

                                byte* lpImageFrameData = lpBuffer + Surface.Width * Surface.Height * 4 * iVisibleLayerIndex;
                                lpFrameData[iVisibleLayerIndex++] = lpImageFrameData;

                                uint uiIndex = 0;
                                for (int y = 0; y < Surface.Height; y++)
                                {
                                    for (int x = 0; x < Surface.Width; x++)
                                    {
                                        ColorBgra Color = Surface.GetPoint(x, y);

                                        lpImageFrameData[uiIndex++] = Color.R;
                                        lpImageFrameData[uiIndex++] = Color.G;
                                        lpImageFrameData[uiIndex++] = Color.B;
                                        lpImageFrameData[uiIndex++] = Color.A;
                                    }
                                }
                            }
                        }

                        if (!VtfLib.vlImageCreateMultiple((uint)Input.Width, (uint)Input.Height, (uint)iVisibleLayers, 1, 1, lpFrameData, ref CreateOptions))
                        {
                            throw new FormatException(VtfLib.vlGetLastError());
                        }
                    }
                }

                uint uiSize;
                byte[] lpOutput = new byte[VtfLib.vlImageGetSize()];
                fixed (byte* lpBuffer = lpOutput)
                {
                    if (!VtfLib.vlImageSaveLump(lpBuffer, (uint)lpOutput.Length, &uiSize))
                    {
                        throw new FormatException(VtfLib.vlGetLastError());
                    }
                }

                Output.Write(lpOutput, 0, (int)uiSize);
            }
            finally
            {
                VtfLib.vlDeleteImage(uiImage);
            }
		}

        public unsafe Document Load(System.IO.Stream Input)
        {
            uint uiImage;
            VtfLib.vlCreateImage(&uiImage);
            VtfLib.vlBindImage(uiImage);

            try
            {
                byte[] lpInput = new byte[Input.Length];

                Input.Read(lpInput, 0, (int)Input.Length);

                fixed (byte* lpBuffer = lpInput)
                {
                    if (!VtfLib.vlImageLoadLump(lpBuffer, (uint)Input.Length, false))
                    {
                        throw new FormatException(VtfLib.vlGetLastError());
                    }
                }

                Document Output = new Document((int)VtfLib.vlImageGetWidth(), (int)VtfLib.vlImageGetHeight());

                for (uint i = 0; i < VtfLib.vlImageGetFrameCount(); i++)
                {
                    BitmapLayer Layer = PaintDotNet.Layer.CreateBackgroundLayer((int)VtfLib.vlImageGetWidth(), (int)VtfLib.vlImageGetHeight());
                    Surface Surface = Layer.Surface;
                    ColorBgra Color = new ColorBgra();

                    if (VtfLib.vlImageGetFrameCount() > 1)
                    {
                        Layer.Name = "Frame " + (i + 1).ToString();
                    }

                    byte[] lpImageData = new byte[VtfLib.vlImageComputeImageSize(VtfLib.vlImageGetWidth(), VtfLib.vlImageGetHeight(), 1, 1, VtfLib.ImageFormat.ImageFormatRGBA8888)];
                    fixed (byte* lpOutput = lpImageData)
                    {
                        if (!VtfLib.vlImageConvert(VtfLib.vlImageGetData(i, 0, 0, 0), lpOutput, VtfLib.vlImageGetWidth(), VtfLib.vlImageGetHeight(), VtfLib.vlImageGetFormat(), VtfLib.ImageFormat.ImageFormatRGBA8888))
                        {
                            throw new FormatException(VtfLib.vlGetLastError());
                        }
                    }

                    uint uiIndex = 0;
                    for (int y = 0; y < Surface.Height; y++)
                    {
                        for (int x = 0; x < Surface.Width; x++)
                        {
                            Color.R = lpImageData[uiIndex++];
                            Color.G = lpImageData[uiIndex++];
                            Color.B = lpImageData[uiIndex++];
                            Color.A = lpImageData[uiIndex++];

                            Surface[x, y] = Color;
                        }
                    }

                    Output.Layers.Add(Layer);
                }

                return Output;
            }
            finally
            {
                VtfLib.vlDeleteImage(uiImage);
            }
		}
	}
}