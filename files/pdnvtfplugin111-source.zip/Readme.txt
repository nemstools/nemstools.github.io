===================================
===================================
 VTF FORMAT PLUG-IN BY: RYAN GREGG
===================================
===================================

===========================
Plug-in/Author Information:
===========================

  Title:
  VTF Format Plug-In for Pain.NET

  Date:
  August 1, 2010

  Author:
  Ryan Gregg

  Build:
  1.1.1

  Email:
  ryansgregg@hotmail.com

  Website:
  http://nemesis.thewavelength.net/

  Written In:
  C#

=============
Installation:
=============

  1) Close Paint.NET.
  2) Extract VTFLib.x86.dll to your ..\Paint.NET\FileTypes\ folder.
  3) Extract VTFLib.x64.dll to your ..\Paint.NET\FileTypes\ folder.
  4) Extract VtfFileType.dll to your ..\Paint.NET\FileTypes\ folder.
  5) Run Paint.NET.

  - This plug-in supports both x86 and x64 architectures and will automatically choose
    which version of VTFLib to load.
  - If the .vtf file format does not appear in your Open/Save dialog, you may be missing
    the Microsoft Visual C++ 2005 SP1 runtime.  You can download this runtime from:

    x86:
    http://www.microsoft.com/downloads/details.aspx?familyid=200b2fd9-ae1a-4a14-984d-389c36f85647

    x64:
    http://www.microsoft.com/downloads/details.aspx?familyid=EB4EBE2D-33C0-4A47-9DD4-B9A6D7BD44DA

======
Notes:
======

  - This is a basic plug-in and is not designed to replace other tools such as VTFEdit.
  - The plug-in only supports single-frame and multiple-frame .vtf files.
  - If a multi-face .vtf file is loaded, only the first face is used.
  - .vtf information such as image format, flags and thumbnail data is not recalled when the
    .vtf is saved again.
  - The DXT file formats are lossy, if you save your .vtfs in this format you should also save
    a backup copy so you can access the original image data.

==========
Changelog:
==========

  v1.1.1
  - Added support for version 7.5 of the VTF format.

  v1.1.0
  - Added x64 support.
  - Upgraded to VTFLib v1.3.0.

  v1.0.4
  - Added support for version 7.4 of the VTF format.
  - Upgraded to VTFLib v1.2.7.

  v1.0.3
  - Added support for version 7.3 of the VTF format.
  - Added version option.
  - Upgraded to VTFLib v1.2.6.

  v1.0.2
  - Image data allocation for animated files no longer done on the stack.

  v1.0.1
  - Fixed flags not saving at all.
  - Improved automatic flag selection.

  v1.0.0
  - Original build.