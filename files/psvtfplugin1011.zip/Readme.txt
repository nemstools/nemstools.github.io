===================================
===================================
 VTF FORMAT PLUG-IN BY: RYAN GREGG
===================================
===================================

===========================
Plug-in/Author Information:
===========================

  Title:
  VTF Format Plug-In for Photoshop

  Date:
  September 16th, 2008

  Author:
  Ryan Gregg

  Build:
  1.0.11

  Email:
  ryansgregg@hotmail.com

  Website:
  http://nemesis.thewavelength.net/

  Written In:
  C

=============
Installation:
=============

  Photoshop:

  1) Close Photoshop.
  2) Extract VTFLib.dll to your ..\Photoshop\ folder.
  3) Extract VTF.8bi to your ..\Photoshop\Plug-Ins\File Formats\ folder.
  4) Run Photoshop.

  Paint Shop Pro:

  1) Close Paint Shop Pro.
  2) Create a folder called VTFLib in your ..\Paint Shop Pro X\Plugins folder
  3) Extract VTFLib.dll and VTF.8bi to your ..\Paint Shop Pro X\Plugins\VTFLib folder.
  4) Run Paint Shop Pro.

======
Notes:
======

  - This is a basic plug-in and is not designed to replace other tools such as VTFEdit.
  - The plug-in only supports single-face and single-frame .vtf files.
  - If a multi-face or multi-frame .vtf file is loaded, only the first frame or face is used.
  - .vtf information such as image format, flags and thumbnail data is not recalled when the
    .vtf is saved again.  The information from the previously loaded .vtf is used.
  - The DXT file formats are lossy, if you save your .vtfs in this format you should also save
    a backup copy so you can access the original image data.

==========
Changelog:
==========

  v1.0.11
  - Fixed alpha channel premultiplying on open.

  v1.0.10
  - Added support for multiple alpha channels.

  v1.0.9
  - Added support for version 7.4 of the VTF format.
  - Upgraded to VTFLib v1.2.7.

  v1.0.8
  - Added support for version 7.3 of the VTF format.
  - Upgraded to VTFLib v1.2.6.

  v1.0.7
  - Added spray templates.
  - Upgraded to VTFLib v1.2.5.

  v1.0.6
  - Added "Mipmaps" option.
  - Upgraded to VTFLib v1.2.2.

  v1.0.5
  - Added support for 16 bit channel reading.
  - Upgraded to VTFLib v1.2.1.

  v1.0.4
  - Upgraded to VTFLib v1.2.0.

  v1.0.3
  - Upgraded to VTFLib v1.1.3.

  v1.0.2
  - Added format templates.

  v1.0.1
  - Improved format specific flag handling.
  - Fixed combobox height.

  v1.0.0
  - Original build.