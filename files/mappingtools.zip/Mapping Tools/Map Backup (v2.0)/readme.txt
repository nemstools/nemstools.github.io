Mapfile backup application README
25/11/02 Anthony Moore

Version 2.0

Instructions:
The actual location of the mapbackup.exe file on the hard drive is irrelevant. Hence, it should be unzipped to a convenient location (eg. beside ZHLT).

The Expert compile mode under Worldcraft or Hammer should then be modified, so that this executable is called with the name of the mapfile before CSG. By default, an incremental backup will be created of your mapfile (mapname0000.map, mapname0001.map, etc) in the same directory everytime you compile. 

You can change the default behavoir by specifying the appropriate switches described below:

 -ext extension   Force a specific extension for all backup files
 -dir             Place backups of all files inside \filename\
 -out path        Force a specific backup path (negates -ext and -dir)
 -max #           Specify a maximum number of backup files to create

 -e, -d, -o and -m are also accepted

Notes:
- You can pass multiple file paths to backup into commandline parameters.
- If no extension exists on the filepath, the tool attempts to look for both an .rmf and a .map file to backup.
- Once the maximum number of backups is reached (defined by -max), the program starts overwriting at 1 and counts up again.

Example: If I wanted to incrementally backup my map and rmf file every compile. I could use the following Expert compile mode command:

    mapbackup.exe $path\$file

Example: If I wanted to backup only the .rmf, within its own folder, and have 30 incremental backup files at one time. I could use the following Expert compile mode command:

    mapbackup.exe $path\$file.rmf -d -m 30

Example: I want to backup my map file and my 3rd hull file (mapname.p2) in their own directory, with a maximum of 50 backup files. I couuld use the following Expert compile mode command:

    mapbackup.exe $path\$file.map $path\$file.p2 -m 50 -d
