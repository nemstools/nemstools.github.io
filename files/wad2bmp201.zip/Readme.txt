==================================
==================================
 wad2bmp BY: RYAN "NEMESIS" GREGG
==================================
==================================

===========================
Program/Author Information:
===========================

---- General Program Information ----
Date                     : Febuary 5th 2005
Author                   : Ryan "NEMESIS" Gregg
Title                    : wad2bmp
Build                    : 2.0.1
Email address            : ryansgregg@hotmail.com
Home page /  Website     : http://nemesis.thewavelength.net/

---- Program Construction Information ----
Written In               : C++

==================
Program Changelog:
==================

  v2.0.1
  - Upgraded to HLLib v1.1.3.

  v2.0.0
  - wad2bmp rewrite using HLLib.

  v1.0.0
  - Original release.

====
FAQ:
====

Q.
  What arguments does wad2bmp take.

A.
  wad2bmp takes the following arguments:

  -p: The path to the package you want to extract.
  -d: The destination folder to extract the package to.

  Examples:

  wad2bmp.exe -p "c:\mywad.wad"
  wad2bmp.exe -p "c:\mybsp.bsp"
  wad2bmp.exe -p "c:\mywad.wad" -d "c:\textures"
  wad2bmp.exe -p "c:\mybsp.bsp" -d "c:\textures"


Q.
  What file formats does wad2bmp support.

A.
  wad2bmp supports textures embedded in both Half-Life WAD and
  Half-Life BSP files.

==============================
Program Copyright-Permissions:
==============================

LICENSE 

Terms and Conditions for Copying, Distributing, and Modifying 

Items other than copying, distributing, and modifying the Content
with which this license was distributed (such as using, etc.) are
outside the scope of this license. 

1. You may copy and distribute exact replicas of wad2bmp as you receive
   it, in any medium, provided that you conspicuously and appropriately
   publish on each copy an appropriate copyright notice and disclaimer
   of warranty; keep intact all the notices that refer to this License
   and to the absence of any warranty; and give any other recipients of
   wad2bmp a copy of this License along with wad2bmp. You may at your
   option charge a fee for the media and/or handling involved in creating
   a unique copy of the wad2bmp for use offline, you may at your option offer
   instructional support for the wad2bmp in exchange for a fee, or you may at
   your option offer warranty in exchange for a fee. You may not charge a
   fee for wad2bmp itself. You may not charge a fee for the sole service
   of providing access to and/or use of wad2bmp via a network (e.g. the Internet),
   whether it be via the world wide web, FTP, or any other method. 

2. You may not modify your copy or copies of wad2bmp or any portion of it.

3. You are not required to accept this License, since you have not signed it.
   However, nothing else grants you permission to copy, distribute or modify wad2bmp.
   These actions are prohibited by law if you do not accept this License. Therefore,
   by copying or distributing wad2bmp you indicate your acceptance of this License to do
   so, and all its terms and conditions for copying, distributing and modifying wad2bmp. 

NO WARRANTY 

4. BECAUSE WAD2BMP IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
   FOR WAD2BMP, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED
   IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE WAD2BMP "AS IS" WITHOUT
   WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
   THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE
   ENTIRE RISK OF USE OF THE WAD2BMP IS WITH YOU. SHOULD WAD2BMP PROVE FAULTY, INACCURATE, OR
   OTHERWISE UNACCEPTABLE YOU ASSUME THE COST OF ALL NECESSARY REPAIR OR CORRECTION. 

5. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
   COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MIRROR AND/OR REDISTRIBUTE WAD2BMP AS
   PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL,
   INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE WAD2BMP,
   EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 
