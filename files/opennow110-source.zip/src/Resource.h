//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AddIn.rc
//
#define IDS_PROJNAME                    100
#define IDR_ADDIN                       101
#define IDR_CONNECT                     102
#define IDD_OPENNOW                     201
#define IDC_FILES                       202
#define IDC_FILTER                      203
#define IDC_PROJECTS                    204
#define IDC_EXPLORE                     205
#define IDC_VIEWCODE                    206

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        207
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         207
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
