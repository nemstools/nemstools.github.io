/*
 *	Open Now!
 *	Copyright (C) 2009-2012 Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "AddIn.h"
#include "Connect.h"
#include "OpenNow.h"
#include "OpenComplementary.h"

namespace
{
	static LPCWSTR lpOpenNow = L"OpenNow.Connect.OpenNow";
	static LPCWSTR lpOpenComplementary = L"OpenNow.Connect.OpenComplementary";
}

extern CAddInModule _AtlModule;

STDMETHODIMP CConnect::OnConnection(IDispatch *pApplication, AddInDesignerObjects::ext_ConnectMode ConnectMode, IDispatch *pAddInInst, SAFEARRAY ** /*custom*/)
{
	HRESULT hr = S_OK;

	pApplication->QueryInterface(__uuidof(EnvDTE80::DTE2), (LPVOID*)&m_pDTE);
	pAddInInst->QueryInterface(__uuidof(EnvDTE::AddIn), (LPVOID*)&m_pAddInInstance);

	if(ConnectMode == 5) // 5 = AddInDesignerObjects::ext_cm_UISetup.
	{
		CComQIPtr<EnvDTE::Commands> pCommands;
		IfFailGoCheck(m_pDTE->get_Commands(&pCommands), pCommands);
		CComQIPtr<EnvDTE80::Commands2> pCommands2 = pCommands;

		CComPtr<EnvDTE::Command> pCommand;

		pCommand.Release();
		if(SUCCEEDED(pCommands2->AddNamedCommand2(m_pAddInInstance, CComBSTR("OpenNow"), CComBSTR("Open File(s) in Solution..."), CComBSTR("Open file(s) in solution."), VARIANT_TRUE, CComVariant(-1), NULL, EnvDTE::vsCommandStatusSupported | EnvDTE::vsCommandStatusEnabled, EnvDTE80::vsCommandStylePictAndText, EnvDTE80::vsCommandControlTypeButton, &pCommand)) && (pCommand))
		{
			CComPtr<IDispatch> pDisp;
			IfFailGoCheck(m_pDTE->get_CommandBars(&pDisp), pDisp);
			CComQIPtr<Microsoft_VisualStudio_CommandBars::_CommandBars> pCommandBars = pDisp;

			CComPtr<Microsoft_VisualStudio_CommandBars::CommandBar> pMenuBarCommandBar;
			IfFailGoCheck(pCommandBars->get_Item(CComVariant(L"MenuBar"), &pMenuBarCommandBar), pMenuBarCommandBar);
			CComPtr<Microsoft_VisualStudio_CommandBars::CommandBarControls> pMenuBarControls;
			IfFailGoCheck(pMenuBarCommandBar->get_Controls(&pMenuBarControls), pMenuBarControls);

			CComPtr<Microsoft_VisualStudio_CommandBars::CommandBarControl> pToolsCommandBarControl;
			IfFailGoCheck(pMenuBarControls->get_Item(CComVariant(L"Tools"), &pToolsCommandBarControl), pToolsCommandBarControl);
			CComQIPtr<Microsoft_VisualStudio_CommandBars::CommandBarPopup> pToolsPopup = pToolsCommandBarControl;

			CComQIPtr<Microsoft_VisualStudio_CommandBars::CommandBar> pToolsCommandBar;
			IfFailGoCheck(pToolsPopup->get_CommandBar(&pToolsCommandBar), pToolsCommandBar);

			pCommand->put_Bindings(CComVariant(L"Global::Ctrl+Shift+Alt+O"));

			pDisp = NULL;
			IfFailGoCheck(pCommand->AddControl(pToolsCommandBar, 1, &pDisp), pDisp);
		}
		/*else if(SUCCEEDED(pCommands2->Item(CComVariant(lpOpenNow), -1, &pCommand)) && (pCommand))
		{
			pCommand->Delete();
		}*/

		pCommand.Release();
		if(SUCCEEDED(pCommands2->AddNamedCommand2(m_pAddInInstance, CComBSTR("OpenComplementary"), CComBSTR("Open Complementary File"), CComBSTR("Open complementary file."), VARIANT_TRUE, CComVariant(-1), NULL, EnvDTE::vsCommandStatusSupported | EnvDTE::vsCommandStatusEnabled, EnvDTE80::vsCommandStylePictAndText, EnvDTE80::vsCommandControlTypeButton, &pCommand)) && (pCommand))
		{
			pCommand->put_Bindings(CComVariant(L"Global::Alt+O"));
		}
		/*else if(SUCCEEDED(pCommands2->Item(CComVariant(lpOpenComplementary), -1, &pCommand)) && (pCommand))
		{
			pCommand->Delete();
		}*/
	}

	return S_OK;
Error:
	return hr;
}

STDMETHODIMP CConnect::OnDisconnection(AddInDesignerObjects::ext_DisconnectMode /*RemoveMode*/, SAFEARRAY ** /*custom*/)
{
	m_pDTE = NULL;
	m_pAddInInstance = NULL;
	return S_OK;
}

STDMETHODIMP CConnect::OnAddInsUpdate(SAFEARRAY ** /*custom*/)
{
	return S_OK;
}

STDMETHODIMP CConnect::OnStartupComplete(SAFEARRAY ** /*custom*/)
{
	return S_OK;
}

STDMETHODIMP CConnect::OnBeginShutdown(SAFEARRAY ** /*custom*/)
{
	return S_OK;
}

STDMETHODIMP CConnect::QueryStatus(BSTR bstrCmdName, EnvDTE::vsCommandStatusTextWanted NeededText, EnvDTE::vsCommandStatus *pStatusOption, VARIANT * /*pvarCommandText*/)
{
	if(NeededText == EnvDTE::vsCommandStatusTextWantedNone)
	{
		if(_wcsicmp(bstrCmdName, lpOpenNow) == 0)
		{
			*pStatusOption = static_cast<EnvDTE::vsCommandStatus>(EnvDTE::vsCommandStatusEnabled | EnvDTE::vsCommandStatusSupported);
		}
		else if(_wcsicmp(bstrCmdName, lpOpenComplementary) == 0)
		{
			COpenComplementary OpenComplementary(m_pDTE);
			if(OpenComplementary.Query())
			{
				*pStatusOption = static_cast<EnvDTE::vsCommandStatus>(EnvDTE::vsCommandStatusEnabled | EnvDTE::vsCommandStatusSupported);
			}
			else
			{
				*pStatusOption = static_cast<EnvDTE::vsCommandStatus>(EnvDTE::vsCommandStatusSupported);
			}
		}
	}
	return S_OK;
}

STDMETHODIMP CConnect::Exec(BSTR bstrCmdName, EnvDTE::vsCommandExecOption ExecuteOption, VARIANT *pvarVariantIn, VARIANT * /*pvarVariantOut*/, VARIANT_BOOL *pvbHandled)
{
	*pvbHandled = VARIANT_FALSE;
	if(ExecuteOption == EnvDTE::vsCommandExecOptionDoDefault)
	{
		if(_wcsicmp(bstrCmdName, lpOpenNow) == 0)
		{
			COpenNow OpenNow(m_pDTE);
			OpenNow.DoModal();

			*pvbHandled = VARIANT_TRUE;
			return S_OK;
		}
		else if(_wcsicmp(bstrCmdName, lpOpenComplementary) == 0)
		{
			COpenComplementary OpenComplementary(m_pDTE);
			OpenComplementary.Execute();
			
			*pvbHandled = VARIANT_TRUE;
			return S_OK;
		}
	}
	return S_OK;
}