========================
========================
Open Now! By: Ryan Gregg
========================
========================

===========================
Program/Author Information:
===========================

Title      : Open Now!
Author     : Ryan Gregg
Build      : 1.1.0
Date       : Feb 21st 2012
Email      : ryansgregg@hotmail.com
Website    : http://nemesis.thewavelength.net/
Written In : C++

====
FAQ:
====

  Q. I've installed Open Now!, where can I find it?

  A. By default, Open Now! will create a command called
     "Open File(s) in Solution..." under your "Tools"
     menu.  The default shortcut is Ctrl+Shift+Alt+O.


  Q. I've looked there but I still can't find Open Now!,
     what could be wrong?

  A. If you were running Visual Studio when you installed
     the Open Now!, you will need to restart Visual Studio
     for Visual Studio to detect the new add-in.  If you
     still cannot find the add-in, you may be running an
     unsupported version of Visual Studio, Open Now!
     currently supports:

     1) Visual Studio 2005, 2008 and 1010


  Q. How can I change the shortcut to Open Now!?

  A. To change the shortcut to Open Now!:

     1) Open Visual Studio.
     2) Select "Tools" then "Customize...".
     3) Select "Keyboard...".
     4) Type "OpenNow.Connect.OpenNow" under "Show command
        containing:".
     5) Select "OpenNow.Connect.OpenNow".
     6) Press "Remove" to remove the old shortcut (commands
        can have multiple shortcuts).
     7) Type your new shortcut under "Press shortcut keys:".
     8) Press "Assign" to add the new shortcut.
     9) Press "OK" then "Close".


  Q. How can I change the menu location of Open Now!?

  A. To change the menu location of Open Now!:

     1) Open Visual Studio.
     2) Select "Tools" then "Customize...".
     3) Find "Open File(s) in Solution..." in the main menu
        toolbar (as if you were going to run it) and drag it
        to your desired location.
     4) Press "Close".


  Q. How can I better control my searches?

  A. There are a number of special characters that can prefix
     search terms.  You can string several special characters
     together to create more advanced terms.  The actual search
     string starts after the first invalid special character
     or opening quote.  These special characters are:

     1) The ampersand (&) specifies that the search string
        should be combined with a logical "and".  (Note, this
        is the default implicit behavior - you probably wont
        even need to type an ampersand).

     2) The vertical bar (|) specifies that the search string
        should be combined with a logical "or".

     3) The hyphon (-) and apostrophe (!) specify that the
        search string should be negated.

     4) The backward slash (\) or forward slash (/) specify
        that the whole file or project path should be searched,
        not just the file or project name.

     5) The colon (:) specifies that the project or project path
        should be searched and not the file name or file path.

     6) The double quote (") can be used to surround the above
        special characters (or spaces) to effectively "escape"
        them.

     7) The asterisk (*) can be used as a multi character
        wildcard.

     8) The question mark (?) can be used as a single character
        wildcard.

     Examples:

     substring .h               : Find all files containing "substring"
                                : in all ".h" files.

     substring |.cpp |.h        : Find all files containing "substring"
                                : in all ".cpp" and ".h" files.

     substring -.h              : Find all files containing "substring"
                                : in all files except ".h" files.

     substring -.cpp -.h        : Find all files containing "substring"
                                : in all files except ".cpp" and ".h" files.

     substring \\include\       : Find all files containing "substring"
                                : in any folder called "include".

     substring :\"header files" : Find all files containing "substring"
                                : in any filter containing "header files".

     :substring                 : Find all files in any project
                                : containing "substring".

     substring *.h              : Find all files containing "substring"
                                : in all files ending in ".h".

==================
Program Changelog:
==================

  v1.1.0
  - Added <Browse...> option to open files outside of your
    solution.
  - Added an OpenComplementary command (Alt+O) to open files
    of the same name but differing extensions.

  v1.0.2
  - Added Visual Studio 2010 support.

  v1.0.1
  - Added Visual Studio 2008 support.

  v1.0.0
  - Original build.

===========================
GNU General Public License:
===========================

Open Now! is licensed under the GNU General Public License,
for the complete license terms, see the GPL.txt file included
in the distribution.