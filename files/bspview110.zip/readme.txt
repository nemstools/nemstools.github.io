Changes:
v1.1.0
-EVS (Entity Visibility Set) calculated for each map off its VIS.
-Use of EVS allows for more accurate e_poly representation.
-The whole world is drawn when you are outside it.
-BSP Load progress displayed.
-Increased some of the limits (they were based in qtool limits).
-Memory leak fixed.

Notes:
-EVS takes a while to calculate on large maps with many entities.
-When outside the world entities and world lightmaps aren�t drawn.

Known Problems:
-Origin brush based entity location problems.
-Loading a new BSP file sometimes crashes app (from last version,
 something isn't freeing right...).

v1.0.0
-Fixed frustum problems.
-Hacked fix for texture problems caused by maps with textures larger then 512 pixels (it'll work up to 1024 now).
-Resize problem on start fixed (the black bar).
-Crosshair stays in middle of screen on resize.
-"Camera position out of range." error removed (your just repositioned at 0, 0, 0).
-GUI added (menu).
-Various additional options that previously were only changed in the config file added to GUI (not all though).
-Optimized wireframe mesh.
-Added a bunch more 'modes' to the edge option (press e or look in menu).
-Keyboard can take multiple keys (ie. you can strafe and walk at the same time).
-Frustum culling added for entity models.
-You can view your entity poly counts now (they probably aren�t culled the same way as in HL though).
-Option to view scene info & crosshair.
-Option to render models or not.
-Option to render entities or not.
-Option to render the skybox or not.
-Solid and textured rendermodes.
-Right click and drag to move camera�s look at position.
-'Z' key puts you into the old mode of 'looking' (like in WC).
-Ability to load a new level without restarting the app.
-WASD can be used to move (R & F for up and down respectively).
-Minor additional optimizations.
-Gave it an icon.

Notes:
-Light Grey Outline = World Poly.
-Blue Outline = Entity Poly.

Known Problems:
-Render Entities can't be set to 0 in config file.
-Origin brush based entity location problems (from original version, I couldn't fix it).