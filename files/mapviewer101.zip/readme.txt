=====================================
=====================================
 MAP VIEWER BY: RYAN "NEMESIS" GREGG
=====================================
=====================================

===========================
Program/Author Information:
===========================

---- General Program Information ----
Original Release Date    : August 6th 2003
Release Date             : September 2nd 2003
Author                   : Ryan "NEMESIS" Gregg
Title                    : MAP Viewer
Build                    : 1.0.1
Email address            : ryansgregg@hotmail.com
Home page /  Website     : http://countermap.counter-strike.net/Nemesis

---- Program Construction Information ----
Programing Time          : About 10 hours.
Writen In                : C++ .NET

==================
Program Changelog:
==================

--- MAP Viewer v1.0.1 ---

  - Texture property viewing.
  - Better console updating.
  - Load bug fixed on computers using different decimal notation conventions.

--- MAP Viewer v1.0.0 ---

  - MAP Viewer released.

==============================
Program Copyright-Permissions:
==============================

This program is Freeware.
