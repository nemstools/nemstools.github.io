//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDR_MAIN_MENU                   101
#define IDI_ICON_HL                     106
#define IDC_FILE_EXIT                   40001
#define IDC_FILE_LOAD                   40002
#define IDC_VIEW_LIGHTING               40003
#define IDC_RENDER_EDGES_VISPOLYENT     40004
#define IDC_RENDER_EDGES_DRWPOLYENT     40005
#define IDC_RENDER_EDGES_DRWPOLYVISENT  40006
#define IDC_RENDER_EDGES_ANTIALIASED    40007
#define IDC_RENDER_SPECIALTEXTURES      40010
#define IDC_CAMERA_CLIP                 40011
#define IDC_VIEW_SWITCHABLETEXTURES     40012
#define IDC_VIEW_INVERTEDMOUSE          40013
#define IDC_RENDER_EDGES_NONE           40014
#define IDC_VIEW_INFO                   40015
#define IDC_RENDER_MODELS               40016
#define IDC_RENDER_ENTITIES             40017
#define IDC_RENDER_TEXTURED             40019
#define IDC_RENDER_SOLID                40020
#define IDC_RENDER_SKY                  40021
#define IDC_VIEW_CROSSHAIR              40022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40024
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
