//
// BSP_tool - botman's Half-Life BSP utilities
//
// (http://planethalflife.com/botman/)
//
// gl_win.cpp
//

/* 
 * HL rendering engine
 * Copyright (c) 2000,2001 Bart Sekura
 *
 * Permission to use, copy, modify and distribute this software
 * is hereby granted, provided that both the copyright notice and 
 * this permission notice appear in all copies of the software, 
 * derivative works or modified versions.
 *
 * THE AUTHOR ALLOWS FREE USE OF THIS SOFTWARE IN ITS "AS IS"
 * CONDITION AND DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES 
 * WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
 *
 * OpenGL window
 */

//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
// See the GNU General Public License for more details at:
// http://www.gnu.org/copyleft/gpl.html
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#include "cmdlib.h"
#include "render.h"
#include "world.h"
#include "config.h"
#include "glwin.h"

extern bool keys[MAX_KEYS];
extern bool left_button;
extern bool right_button;
extern int  xpos;
extern int  ypos;
extern int  m_width;
extern int  m_height;
extern bool m_center_window;
extern bool m_fullscreen;

extern World world;
extern Render render;

extern Config config;

bool antialiased;
extern bool switchable_texture_off;

/////////////////////////////////////////////////////////////////
void
GLWindow::GLInfo::init()
{
    const char* vendor = (const char*) glGetString(GL_VENDOR);
    const char* version = (const char*) glGetString(GL_VERSION);
    const char* renderer = (const char*) glGetString(GL_RENDERER);

    const char* error = "error";
    m_vendor = vendor ? vendor : error;
    m_version = version ? version : error;
    m_renderer = renderer ? renderer : error;

    const char* ext = (const char*) glGetString(GL_EXTENSIONS);
    if(ext) {
        // parse extensions
        char* s = new char[strlen(ext)+1];
        if (!s)
            Error("Error allocating GLInfo memory!\n");
        strcpy(s, ext);
        char seps[] = " ";
        char* token = strtok(s, seps);
        while(token) {
            m_extensions.push_back(token);
            token = strtok(0, seps);
        }
        delete s;
    }
}

///////////////////////////////////////////////////////////////////

const char* GLWindow::className = "GL Engine";
GLWindow* GLWindow::m_instance = 0;
GLWindow::GLInfo GLWindow::gl_info;
vector<DEVMODE> GLWindow::m_modes;

void
GLWindow::create(int width, int height, int bpp, int hz, bool fullscreen)
{
    int x_pos, y_pos;

    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_HREDRAW | CS_VREDRAW | CS_OWNDC, 
                      WindowProc, 0L, 0L,
                      GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
                      className, NULL };

    RegisterClassEx(&wc);
    m_hinst = wc.hInstance;

	if(config.show_edges == 2 || config.show_edges == 4 || config.show_edges == 6)
		antialiased = TRUE;

    // if window exists, kill it
    if(m_instance) {
        m_instance->destroy();
        m_instance = 0;
    }

    // go fullscreen in requested
    if(fullscreen) {
        DEVMODE dm;
        memset(&dm, 0, sizeof(dm));
        dm.dmSize=sizeof(dm);
        dm.dmPelsWidth    = width;
        dm.dmPelsHeight    = height;
        dm.dmBitsPerPel    = bpp;
        dm.dmFields        = DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

        if(hz) {
            dm.dmDisplayFrequency = hz;
            dm.dmFields |= DM_DISPLAYFREQUENCY;
        }

        if(ChangeDisplaySettings(&dm, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL) {
            Error("Error starting in Fullscreen mode!\n");
        }
    }

    // Create a window
    DWORD style;
    DWORD exStyle;

    if(fullscreen) {
        exStyle = WS_EX_TOPMOST|WS_EX_APPWINDOW;
        style = WS_POPUP;
    }
    else {
        exStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
        style = WS_OVERLAPPEDWINDOW;
    }

    x_pos = 0;
    y_pos = 0;

    if ((config.x_pos < 0) && (config.y_pos < 0))
       m_center_window = TRUE;
    else
    {
       m_center_window = FALSE;

       x_pos = config.x_pos;
       y_pos = config.y_pos;
    }

	m_hmenu = LoadMenu(wc.hInstance, MAKEINTRESOURCE(IDR_MAIN_MENU));
    m_hwnd = CreateWindowEx(exStyle,
                            className,
                            "BSP View",
                            style,
                            x_pos,
                            y_pos,
                            width,
                            height,
                            0,
                            m_hmenu,
                            wc.hInstance,
                            0);
    if (!m_hwnd) {
        Error("Error creating Window!\n");
    }

    m_hdc = GetDC(m_hwnd);
    if(!m_hdc) {
        Error("Error Getting Device Context!\n");
    }

    static PIXELFORMATDESCRIPTOR pfd =
    {
        sizeof(PIXELFORMATDESCRIPTOR),
        1,                                    // Version Number
        PFD_DRAW_TO_WINDOW |                // Format Must Support Window
        PFD_SUPPORT_OPENGL |                // Format Must Support OpenGL
        PFD_DOUBLEBUFFER,                    // Must Support Double Buffering
        PFD_TYPE_RGBA,                        // Request An RGBA Format
        bpp,                                // Select Our Color Depth
        0, 0, 0, 0, 0, 0,                    // Color Bits Ignored
        0,                                    // No Alpha Buffer
        0,                                    // Shift Bit Ignored
        0,                                    // No Accumulation Buffer
        0, 0, 0, 0,                            // Accumulation Bits Ignored
        32,                                    // Z-Buffer (Depth Buffer) bits
        0,                                    // No Stencil Buffer
        0,                                    // No Auxiliary Buffer
        PFD_MAIN_PLANE,                        // Main Drawing Layer
        0,                                    // Reserved
        0, 0, 0                                // Layer Masks Ignored
    };

    GLuint pixFmt = 0;
    if(!(pixFmt = ChoosePixelFormat(m_hdc, &pfd))) {
        Error("Error in ChoosePixelFormat!\n");
    }

    if(!SetPixelFormat(m_hdc, pixFmt, &pfd)) {
        Error("Error in SetPixelFormat!\n");
    }

    if(!(m_hrc = wglCreateContext(m_hdc))) {
        Error("Error in wglCreateContext!\n");
    }

    if(!wglMakeCurrent(m_hdc, m_hrc)) {
        Error("Error in wglMakeCurrent!\n");
    }

    m_instance = this;
    m_width = width;
    m_height = height;
    m_bpp = bpp;
    m_fullscreen = fullscreen;
	config.render_entities = TRUE; // This is for some mind-boggleing reason that
								   // I don't want to look into being set to false
								   // at the program's start so here we go...

	resize();

    ShowWindow(m_hwnd, SW_SHOW);
    UpdateWindow(m_hwnd);
    SetForegroundWindow(m_hwnd);
    SetFocus(m_hwnd);

    enum_display();
    gl_info.init();

	sprintf(m_title, "BSP View | %s %s %s", (const char*) glGetString(GL_RENDERER), (const char*) glGetString(GL_VERSION), (const char*) glGetString(GL_VENDOR));
	//SetWindowText(m_hwnd, m_title);

	// Check menu items according to configuration.
	// View
	if(config.show_info == TRUE)
		CheckMenuItem(m_hmenu, IDC_VIEW_INFO, MF_BYCOMMAND | MF_CHECKED);

	if(config.show_crosshair == TRUE)
		CheckMenuItem(m_hmenu, IDC_VIEW_CROSSHAIR, MF_BYCOMMAND | MF_CHECKED);

	if(config.enable_lighting == TRUE)
		CheckMenuItem(m_hmenu, IDC_VIEW_LIGHTING, MF_BYCOMMAND | MF_CHECKED);

	CheckMenuItem(m_hmenu, IDC_VIEW_SWITCHABLETEXTURES, MF_BYCOMMAND | MF_CHECKED);

	if(config.enable_inverted_mouse == TRUE)
		CheckMenuItem(m_hmenu, IDC_VIEW_INVERTEDMOUSE, MF_BYCOMMAND | MF_CHECKED);

	// Render
	if(config.enable_textures == TRUE)
		CheckMenuItem(m_hmenu, IDC_RENDER_TEXTURED, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hmenu, IDC_RENDER_SOLID, MF_BYCOMMAND | MF_CHECKED);

	if(config.render_entities == TRUE)
		CheckMenuItem(m_hmenu, IDC_RENDER_ENTITIES , MF_BYCOMMAND | MF_CHECKED);

	if(config.render_special_textures == TRUE)
		CheckMenuItem(m_hmenu, IDC_RENDER_SPECIALTEXTURES , MF_BYCOMMAND | MF_CHECKED);

	if(config.render_models == TRUE)
		CheckMenuItem(m_hmenu, IDC_RENDER_MODELS , MF_BYCOMMAND | MF_CHECKED);

	if(config.render_sky == TRUE)
		CheckMenuItem(m_hmenu, IDC_RENDER_SKY , MF_BYCOMMAND | MF_CHECKED);

	switch(config.show_edges) {
		case 0:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_CHECKED);
			break;
		case 1:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_CHECKED);
			break;
		case 2:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_CHECKED);
			break;
		case 3:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_CHECKED);
			break;
		case 4:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYENT , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_CHECKED);
			break;
		case 5:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_CHECKED);
			break;
		case 6:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYVISENT , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_CHECKED);
			break;
	};
	// Camera
	if(config.enable_noclip == FALSE)
		CheckMenuItem(m_hmenu, IDC_CAMERA_CLIP, MF_BYCOMMAND | MF_CHECKED);

    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    SwapBuffers(m_hdc);

	//m_print_text = TRUE;
	//AddText("Starting");
	//AddText("App");

	printf("Line one\n\t\tLine two\n"); 

    init();

    m_active = TRUE;
}

void
GLWindow::destroy()
{
    if(m_fullscreen) {
        ChangeDisplaySettings(0, 0);
        ShowCursor(TRUE);
    }

    if(m_hrc) {
        if(!wglMakeCurrent(0, 0)) {
        }

        if(!wglDeleteContext(m_hrc)) {
        }

        m_hrc = 0;
    }

    if(m_hdc) {
        if(!ReleaseDC(m_hwnd, m_hdc)) {
        }
    }

    if(m_hwnd) {
        if(!DestroyWindow(m_hwnd)) {
        }
    }

    UnregisterClass(className, m_hinst);
    m_hinst = 0;
    m_width = 0;
    m_height = 0;
    m_bpp = 0;
    m_fullscreen = FALSE;
    m_active = FALSE;
}

void
GLWindow::OnEdgeChange() {
	switch(config.show_edges) {
		case 0:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYENT  , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYVISENT , MF_BYCOMMAND | MF_UNCHECKED);

			if(antialiased == TRUE)
				CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case 1:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYENT  , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYVISENT , MF_BYCOMMAND | MF_UNCHECKED);

			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case 2:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYENT  , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYVISENT , MF_BYCOMMAND | MF_UNCHECKED);

			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_CHECKED);
			break;
		case 3:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYENT  , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYVISENT , MF_BYCOMMAND | MF_UNCHECKED);

			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case 4:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYENT  , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYVISENT , MF_BYCOMMAND | MF_UNCHECKED);

			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_CHECKED);
			break;
		case 5:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYENT  , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYVISENT , MF_BYCOMMAND | MF_CHECKED);

			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case 6:
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_NONE , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_VISPOLYENT , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYENT  , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_DRWPOLYVISENT , MF_BYCOMMAND | MF_CHECKED);

			CheckMenuItem(m_hmenu, IDC_RENDER_EDGES_ANTIALIASED , MF_BYCOMMAND | MF_CHECKED);
			break;
	};
}

BOOL
GLWindow::OnCommand(int nCmdID, int nEvent) {
	switch (nCmdID)	{
		// File
		case IDC_FILE_LOAD:
			m_active = FALSE;

			world.LoadBSP(NULL);

			m_active = TRUE;
			break;
		case IDC_FILE_EXIT:
		    sprintf(m_load_title, "BSP View | Freeing World");
		    SetWindowText(m_hwnd, m_load_title);
			PostQuitMessage(0);
			break;

		// View
		case IDC_VIEW_INFO:
			config.show_info = !config.show_info;

			if(config.show_info == TRUE)
				CheckMenuItem(m_hmenu, IDC_VIEW_INFO, MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_VIEW_INFO, MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_VIEW_CROSSHAIR:
			config.show_crosshair = !config.show_crosshair;

			if(config.show_crosshair == TRUE)
				CheckMenuItem(m_hmenu, IDC_VIEW_CROSSHAIR, MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_VIEW_CROSSHAIR, MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_VIEW_LIGHTING:
			config.enable_lighting = !config.enable_lighting;

			if(config.enable_lighting == TRUE)
				CheckMenuItem(m_hmenu, IDC_VIEW_LIGHTING, MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_VIEW_LIGHTING, MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_VIEW_SWITCHABLETEXTURES:
			switchable_texture_off = !switchable_texture_off;

			if(switchable_texture_off == FALSE)
				CheckMenuItem(m_hmenu, IDC_VIEW_SWITCHABLETEXTURES, MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_VIEW_SWITCHABLETEXTURES, MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_VIEW_INVERTEDMOUSE:
			config.enable_inverted_mouse = !config.enable_inverted_mouse;

			if(config.enable_inverted_mouse == TRUE)
				CheckMenuItem(m_hmenu, IDC_VIEW_INVERTEDMOUSE, MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_VIEW_INVERTEDMOUSE, MF_BYCOMMAND | MF_UNCHECKED);
			break;

		// Render
		case IDC_RENDER_TEXTURED:
			config.enable_textures = TRUE;

			CheckMenuItem(m_hmenu, IDC_RENDER_TEXTURED , MF_BYCOMMAND | MF_CHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_SOLID , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_RENDER_SOLID:
			config.enable_textures = FALSE;

			CheckMenuItem(m_hmenu, IDC_RENDER_TEXTURED , MF_BYCOMMAND | MF_UNCHECKED);
			CheckMenuItem(m_hmenu, IDC_RENDER_SOLID , MF_BYCOMMAND | MF_CHECKED);
			break;
		case IDC_RENDER_ENTITIES:
			config.render_entities = !config.render_entities;

			if(config.render_entities == TRUE)
				CheckMenuItem(m_hmenu, IDC_RENDER_ENTITIES , MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_RENDER_ENTITIES , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_RENDER_SPECIALTEXTURES:
			config.render_special_textures = !config.render_special_textures;

			if(config.render_special_textures == TRUE)
				CheckMenuItem(m_hmenu, IDC_RENDER_SPECIALTEXTURES , MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_RENDER_SPECIALTEXTURES , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_RENDER_MODELS:
			config.render_models = !config.render_models;

			if(config.render_models == TRUE)
				CheckMenuItem(m_hmenu, IDC_RENDER_MODELS , MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_RENDER_MODELS , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_RENDER_SKY:
			config.render_sky = !config.render_sky;

			if(config.render_sky == TRUE)
				CheckMenuItem(m_hmenu, IDC_RENDER_SKY , MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_RENDER_SKY , MF_BYCOMMAND | MF_UNCHECKED);
			break;
		case IDC_RENDER_EDGES_NONE:
			config.show_edges = 0;

			OnEdgeChange();
			break;
		case IDC_RENDER_EDGES_VISPOLYENT:
			config.show_edges = 1;

			if(antialiased == TRUE)
				config.show_edges++;

			OnEdgeChange();
			break;
		case IDC_RENDER_EDGES_DRWPOLYENT:
			config.show_edges = 3;

			if(antialiased == TRUE)
				config.show_edges++;
			OnEdgeChange();

			break;
		case IDC_RENDER_EDGES_DRWPOLYVISENT:
			config.show_edges = 5;

			if(antialiased == TRUE)
				config.show_edges++;

			OnEdgeChange();
			break;
		case IDC_RENDER_EDGES_ANTIALIASED:
			if(config.show_edges != 0)
			{
				if(antialiased == TRUE)
					config.show_edges--;
				else
					config.show_edges++;
			}

			antialiased = !antialiased;

			OnEdgeChange();
			break;

		// Camera
		case IDC_CAMERA_CLIP:
			config.enable_noclip = !config.enable_noclip;

			if(config.enable_noclip == FALSE)
				CheckMenuItem(m_hmenu, IDC_CAMERA_CLIP, MF_BYCOMMAND | MF_CHECKED);
			else
				CheckMenuItem(m_hmenu, IDC_CAMERA_CLIP, MF_BYCOMMAND | MF_UNCHECKED);
			break;
		default:
			return FALSE;
	}
	return TRUE;
}

/*void
GLWindow::AddText(const char *text)
{
	strcat(m_text, text);

	if (m_print_text)
	{
		PAINTSTRUCT ps;
		HDC hdc;
		RECT rt;
		hdc = BeginPaint(m_hwnd, &ps);
		GetClientRect(m_hwnd, &rt);
		DrawText(hdc, m_text, strlen(m_text), &rt, DT_LEFT);
		EndPaint(m_hwnd, &ps);
	}
}*/

LRESULT
GLWindow::window_proc(UINT msg, WPARAM wparam, LPARAM lparam)
{
    switch(msg) {
        case WM_ACTIVATE:
            if(wparam == WA_INACTIVE) {
                m_active = FALSE;
            }
            else if ((wparam == WA_ACTIVE) ||
                     (wparam == WA_CLICKACTIVE)) {
                m_active = TRUE;
            }

            return 0;

        case WM_CLOSE:
		    sprintf(m_load_title, "BSP View | Freeing World");
		    SetWindowText(m_hwnd, m_load_title);
            PostQuitMessage(0);
            return 0;

        case WM_SIZE:
            if(wparam == SIZE_MINIMIZED) {
                m_active = FALSE;
                return 0;
            }
            else 
            if ((wparam == SIZE_RESTORED) ||
                (wparam == SIZE_MAXIMIZED)) {
                m_active = TRUE;
            }
            m_width = LOWORD(lparam);
            m_height = HIWORD(lparam);
            resize();
            return 0;

		/*case WM_PAINT:
			if (m_print_text)
			{
				PAINTSTRUCT ps;
				HDC hdc;
				RECT rt;
				hdc = BeginPaint(m_hwnd, &ps);
				GetClientRect(m_hwnd, &rt);
				DrawText(hdc, m_text, strlen(m_text), &rt, DT_LEFT);
				EndPaint(m_hwnd, &ps);
			}
			return 0;*/

		case WM_COMMAND:
			if(!OnCommand(LOWORD(wparam), HIWORD(wparam)))
				return DefWindowProc(m_hwnd, msg, wparam, lparam);
			else
				return 0;

        case WM_KEYDOWN:
            keys[wparam] = TRUE;
            if(wparam == VK_ESCAPE) {
				sprintf(m_load_title, "BSP View | Freeing World");
				SetWindowText(m_hwnd, m_load_title);
                PostQuitMessage(0);
            }
            return 0;

        case WM_KEYUP:
            keys[wparam] = FALSE;
            return 0;

        case WM_MOUSEMOVE:
            {
                POINT p;

                GetCursorPos(&p);

                if(!m_fullscreen)
                    ScreenToClient(m_hwnd,&p);

                xpos = (float) p.x;
                ypos = (float) p.y;
            }
            return 0;

        case WM_LBUTTONDOWN:
            left_button = TRUE;
            return 0;

        case WM_LBUTTONUP:
            left_button = FALSE;
            return 0;

        case WM_RBUTTONDOWN:
            right_button = TRUE;
            return 0;

        case WM_RBUTTONUP:
            right_button = FALSE;
            return 0;
    }

    return DefWindowProc(m_hwnd, msg, wparam, lparam);
}

void
GLWindow::enum_display()
{
    if(m_modes.size()) {
        return;
    }

    int c  = 0;
    DEVMODE mode;
    while(EnumDisplaySettings(0, c++, &mode)) {
        if(mode.dmBitsPerPel >= 16 &&   // only 16bpp or more
            mode.dmPelsWidth >= 640 &&  // at least 640x...
            mode.dmDisplayFlags == 0)   // color and noninterlaced
        {
            m_modes.push_back(mode);
        }
    }
}

